//CPAN 144 Project - Group 3
// Bruce Balutan
// Miguel Sevilla
// Paola Perez

import './App.css';
import react, { Component } from "react";
import Button from "react-bootstrap/Button";
import "bootstrap/dist/css/bootstrap.min.css";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import { LinkContainer } from "react-router-bootstrap";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Card from 'react-bootstrap/Card';


function App() {
  return (
    <div>
      <BrowserRouter>
        <div>
          <NavBar />
        </div>

        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/About" element={<AboutPage />} />
          <Route path="/Adoption" element={<PetRetrieve />} />
          <Route path="/Registration" element={<Registration />} />
        </Routes>

      </BrowserRouter>

    </div>
  );
}

function NavBar() {
  return (
    <div>
      <Navbar bg={"dark"} variant={"dark"} sticky="top" expand="lg" collapseOnSelect>
        <Container >
          <Navbar.Brand >
            <LinkContainer to={"/"}>
              <Nav.Link>Place Holder</Nav.Link>
            </LinkContainer>
          </Navbar.Brand>

        </Container>
        <Navbar.Toggle className="toggler" />
        <Navbar.Collapse>
          <Nav as="ul" className="NavLinks" >

            <LinkContainer to={"/AboutPage"}>
              <Nav.Link>About</Nav.Link>
            </LinkContainer>

            <LinkContainer to={"/Animals"}>
              <Nav.Link>Animals</Nav.Link>
            </LinkContainer>
            <LinkContainer to={"/Volunteering"}>
              <Nav.Link>Volunteering</Nav.Link>
            </LinkContainer>
            <LinkContainer to={"/Registration"}>
              <Nav.Link>Register</Nav.Link>
            </LinkContainer>
            <LinkContainer to={"/Contact"}>
              <Nav.Link>Contact</Nav.Link>
            </LinkContainer>
            <LinkContainer className="NavButton" variant={"dark"} to={"/Donate"}>
              <Button >Donate</Button>
            </LinkContainer>
          </Nav>
        </Navbar.Collapse>
      </Navbar>
    </div>
  )
}

function Footer() {
  return (
    <div>
      <footer class="bg-dark text-white pt-5 pb-4" id="footer">
        <div class="container text-center text-md-left">
          <div class="row text-center text-md-left">
            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
              <h5 class="text-uppercase mb-4 font-weight-bold text-white">
                Pet Adoption Agency About Us
              </h5>
              <p>Random Text to fill out everything</p>
            </div>
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
              <h5 class="text-uppercase mb-4 font-weight-bold text-white">
                Animals
              </h5>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Dogs</a>
              </p>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Cats</a>
              </p>
            </div>
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
              <h5 class="text-uppercase mb-4 font-weight-bold text-white">
                Volunteering
              </h5>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Location One</a>
              </p>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Location Two</a>
              </p>
            </div>
            <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
              <h5 class="text-uppercase mb-4 font-weight-bold text-white">
                User
              </h5>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Register</a>
              </p>
              <p>
                <a href="/" class="text-white" style={{ textDecoration: "none" }}>Sign in</a>
              </p>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
              <h5 class="text-uppercase mb-4 font-weight-bold text-white">
                Contact
              </h5>
              <p>
                Phone Number
              </p>
              <p>
                Email
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

function HomePage() {
  return (<div >
    <div id="full">
      <Card border="light">
        <Card.Body>
          <Card.Img src="https://thumbs.dreamstime.com/b/dog-cat-together-wide-angle-9452010.jpg" className="card-image-top" />
          <Card.ImgOverlay>
            <div className="p-5">
              <Card.Title>Pet Adoption Agency</Card.Title>
              <Card.Subtitle className="mb2 text-muted">Rescuing Toronto's Cats and Dogs</Card.Subtitle>
              <Card.Text>
                All-volunteer, no-kill animal shelter,
              </Card.Text>
              <LinkContainer variant={"dark"} to={"/Adoption"}>
                <Button>Adoption</Button>
              </LinkContainer>
            </div>
          </Card.ImgOverlay>
        </Card.Body>
      </Card>
    </div>
    <Footer /></div>);
}

function AboutPage() {

}

class Registration extends Component {

  constructor(props) {
    super(props);

    this.state = {
      firstName: '',
      lastName: '',
      email: ''
    }

    this.onChange = this.onChange.bind(this);
    this.onSubmitHandler = this.onSubmitHandler.bind(this);
  }

  onChange(e) {
    let inputName = e.target.name;
    let inputVal = e.target.value;

    this.setState({ [inputName]: inputVal });
  }

  onSubmitHandler(event) {

    if (this.state.firstName === "") {
      alert("Please enter your first name.")
      event.preventDefault();
    } else if (this.state.lastName === "") {
      alert("Please enter your last name.")
      event.preventDefault();
    } else if (this.state.email === "") {
      alert("Please enter your email.")
      event.preventDefault();
    } else {
      alert("Successfully registered!")
    }
  }

  render() {
    return (
    <>
      <h2>Register Your Account Down Below</h2>

      <form id="register" onSubmit={this.onSubmitHandler}>
        <h3>Fill in the details here:</h3>
        <input type="text" name="firstName" placeholder='First Name...' onChange={this.onChange} />
        <input type="text" name="lastName" placeholder='Last Name...' onChange={this.onChange} />
        <input type="text" name="email" placeholder='Email...' onChange={this.onChange} />
        <button>Register</button>
      </form>
    </>
    )
  }

}

class PetRetrieve extends Component {
  constructor() {
    super();
    this.state = { message: [] };
  }
  componentDidMount() {
    var url = "https://dog.ceo/api/breeds/image/random";
    fetch(url)
      .then((response) => response.json())
      .then((json) => {
        this.setState({ message: json.message });
      });
  }
  render() {
    return (<div>
      <Pet
        breed={this.state.message}
      />
    </div>)
  }
}

function Pet(props) {
  return <div>
    <h1>Pet up for adoption: </h1>
    <img src={props.breed}></img>
    <p> Fill in information on pet here such as breed, age, etc </p>
  </div>

}

export default App;

